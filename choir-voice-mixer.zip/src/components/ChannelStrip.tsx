import React, { useEffect, useRef, useState } from "react";
import { Voice } from "../types";
import { player } from "../lib/audioEngine";
import { Volume2, VolumeX, Mic } from "lucide-react";

interface ChannelStripProps {
  voice: Voice;
  onVolumeChange: (vol: number) => void;
  onMuteToggle: () => void;
  onSoloToggle: () => void;
  onPanChange: (pan: number) => void;
  isPlaying: boolean;
}

export const ChannelStrip: React.FC<ChannelStripProps> = ({
  voice,
  onVolumeChange,
  onMuteToggle,
  onSoloToggle,
  onPanChange,
  isPlaying,
}) => {
  const sliderRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [level, setLevel] = useState(0); // 0.0 to 1.0
  const animFrameRef = useRef<number | null>(null);

  // Animate the LED level meter when playing
  useEffect(() => {
    const updateMeter = () => {
      if (isPlaying) {
        const rawLevel = player.getChannelAudioLevel(voice.id);
        // Add a small amount of damping/falloff for a smooth professional audio response
        setLevel((prev) => {
          if (rawLevel > prev) return rawLevel;
          return prev * 0.85 + rawLevel * 0.15; // Smooth decay
        });
      } else {
        setLevel((prev) => (prev > 0.01 ? prev * 0.7 : 0)); // Quickly decay to 0 on stop
      }
      animFrameRef.current = requestAnimationFrame(updateMeter);
    };

    updateMeter();

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [isPlaying, voice.id]);

  // Handle Dragging for Vertical Slider
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDragging(true);
    updateVolumeFromPointer(e);
    if (sliderRef.current) {
      sliderRef.current.setPointerCapture(e.pointerId);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    updateVolumeFromPointer(e);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDragging(false);
    if (sliderRef.current) {
      sliderRef.current.releasePointerCapture(e.pointerId);
    }
  };

  const updateVolumeFromPointer = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    // Invert because vertical slider: 100% is top, 0% is bottom
    const relativeY = rect.bottom - e.clientY;
    let percentage = relativeY / rect.height;
    percentage = Math.max(0, Math.min(1, percentage));
    onVolumeChange(percentage);
  };

  // Color Mapping based on standard parts or custom colors
  const getColorClasses = (col: string) => {
    switch (col) {
      case "indigo":
        return {
          text: "text-indigo-400",
          bg: "bg-indigo-500",
          accent: "indigo",
          border: "border-indigo-500/20",
          shadow: "shadow-indigo-500/10",
        };
      case "pink":
        return {
          text: "text-pink-400",
          bg: "bg-pink-500",
          accent: "pink",
          border: "border-pink-500/20",
          shadow: "shadow-pink-500/10",
        };
      case "sky":
        return {
          text: "text-sky-400",
          bg: "bg-sky-500",
          accent: "sky",
          border: "border-sky-500/20",
          shadow: "shadow-sky-500/10",
        };
      case "emerald":
        return {
          text: "text-emerald-400",
          bg: "bg-emerald-500",
          accent: "emerald",
          border: "border-emerald-500/20",
          shadow: "shadow-emerald-500/10",
        };
      default:
        return {
          text: "text-amber-400",
          bg: "bg-amber-500",
          accent: "amber",
          border: "border-amber-500/20",
          shadow: "shadow-amber-500/10",
        };
    }
  };

  const themeColors = getColorClasses(voice.color);

  // Generate 15 LED segments: Red (top), Yellow (mid), Green (low)
  const numSegments = 16;
  const segments = Array.from({ length: numSegments }).map((_, idx) => {
    const segIndex = numSegments - 1 - idx; // 15 is top, 0 is bottom
    const isLit = level * numSegments > segIndex;
    
    // Determine LED Color based on position
    let activeColor = "bg-emerald-500 shadow-[0_0_4px_#10b981]";
    let inactiveColor = "bg-emerald-950/40";

    if (segIndex >= 13) {
      // Top 3 Red
      activeColor = "bg-rose-500 shadow-[0_0_4px_#f43f5e]";
      inactiveColor = "bg-rose-950/30";
    } else if (segIndex >= 9) {
      // Middle 4 Yellow
      activeColor = "bg-amber-400 shadow-[0_0_4px_#fbbf24]";
      inactiveColor = "bg-amber-950/30";
    }

    return (
      <div
        key={segIndex}
        className={`h-2 w-full rounded-sm transition-colors duration-75 ${
          isLit ? activeColor : inactiveColor
        }`}
      />
    );
  });

  return (
    <div
      id={`strip-${voice.id}`}
      className={`flex flex-col glass-panel rounded-2xl ${
        voice.isSolo 
          ? "border-amber-400/30 shadow-[0_0_15px_rgba(245,158,11,0.1)]" 
          : "shadow-lg shadow-black/15"
      } p-4 w-full select-none transition-all duration-300 hover:scale-[1.01] hover:border-white/15`}
    >
      {/* Header Info */}
      <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-3">
        <div className="flex items-center gap-2">
          <Mic className={`h-4 w-4 ${themeColors.text}`} />
          <span className="font-display font-semibold text-slate-100 text-sm tracking-wide">
            {voice.name}
          </span>
        </div>
        <div className="text-[10px] font-mono text-slate-400 bg-white/5 px-1.5 py-0.5 rounded border border-white/5">
          CH {voice.name.charAt(0).toUpperCase()}
        </div>
      </div>

      {/* Sliders and Visualizer Row */}
      <div className="flex items-stretch justify-center gap-6 h-64 my-2">
        
        {/* Custom Vertical Volume Slider Container */}
        <div className="flex flex-col items-center flex-1 h-full relative">
          <div className="text-[10px] font-mono text-slate-500 mb-1">0</div>
          
          <div
            ref={sliderRef}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            className="relative w-8 h-full bg-white/5 rounded-full flex items-center justify-center cursor-pointer border border-white/10 select-none group"
          >
            {/* Active Track Highlight */}
            <div
              className={`absolute bottom-0 w-1.5 rounded-b-full transition-all duration-75 ${themeColors.bg} opacity-30`}
              style={{ height: `${voice.volume * 100}%` }}
            />
            
            {/* Track Center Line */}
            <div className="absolute w-0.5 h-[90%] bg-white/10 rounded-full" />

            {/* Slider Knob */}
            <div
              className="absolute w-6 h-6 rounded-full bg-white shadow-[0_0_15px_rgba(255,255,255,0.35)] transition-transform duration-75 cursor-grab active:cursor-grabbing flex items-center justify-center"
              style={{ 
                bottom: `calc(${voice.volume * 100}% - 12px)`,
                transform: isDragging ? "scale(1.15)" : "scale(1)",
                border: `4px solid ${
                  voice.color === "indigo" ? "#3b82f6" :
                  voice.color === "pink" ? "#ec4899" :
                  voice.color === "sky" ? "#0ea5e9" :
                  voice.color === "emerald" ? "#10b981" : "#f59e0b"
                }`
              }}
            >
              {/* Central dot on knob */}
              <div className="w-1 h-1 bg-slate-900 rounded-full" />
            </div>
          </div>
          
          <div className="text-[10px] font-mono text-slate-500 mt-1">-60</div>
        </div>

        {/* LED Peak Meter */}
        <div className="w-6 flex flex-col justify-between h-full bg-white/5 rounded-lg p-1.5 border border-white/5 gap-1.5">
          {segments}
        </div>
      </div>

      {/* Volume Display & Solo/Mute Controls */}
      <div className="mt-4 flex flex-col gap-3">
        {/* Percentage Display */}
        <div className="flex items-center justify-between text-xs text-slate-300 bg-white/5 border border-white/5 px-2.5 py-1.5 rounded-lg font-mono">
          <span className="text-[10px] text-slate-500">VOL:</span>
          <span className="text-slate-100 font-medium">
            {Math.round(voice.volume * 100)}%
          </span>
        </div>

        {/* Panning Control */}
        <div className="flex flex-col gap-1.5 bg-white/5 border border-white/5 px-2.5 py-2 rounded-lg font-mono">
          <div className="flex items-center justify-between text-[10px] text-slate-400">
            <span className="text-slate-500 font-bold uppercase tracking-wider">PANNING:</span>
            <button
              onClick={() => onPanChange(0.0)}
              className="text-blue-400 hover:text-blue-300 cursor-pointer transition-all font-bold text-[10px]"
              title="Reset to Center"
            >
              {(() => {
                const panValue = voice.pan ?? 0.0;
                if (panValue === 0) return "Center";
                if (panValue < 0) return `L ${Math.round(Math.abs(panValue) * 100)}`;
                return `R ${Math.round(panValue * 100)}`;
              })()}
            </button>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-[10px] text-slate-500 font-bold w-3 text-center">L</span>
            <input
              type="range"
              min="-1"
              max="1"
              step="0.05"
              value={voice.pan ?? 0.0}
              onChange={(e) => onPanChange(parseFloat(e.target.value))}
              className="flex-1 h-1 bg-white/10 rounded-lg appearance-none cursor-ew-resize accent-blue-500 hover:accent-blue-400 focus:outline-none"
            />
            <span className="text-[10px] text-slate-500 font-bold w-3 text-center">R</span>
          </div>
        </div>

        {/* Mute and Solo Button Strip */}
        <div className="grid grid-cols-2 gap-2">
          {/* Solo Button (S) */}
          <button
            id={`solo-${voice.id}`}
            onClick={onSoloToggle}
            className={`py-1.5 px-3 rounded-lg border font-bold text-xs transition-all duration-150 cursor-pointer ${
              voice.isSolo
                ? "bg-amber-500 border-amber-400 text-slate-950 shadow-md shadow-amber-500/10"
                : "bg-white/5 border-white/5 text-slate-400 hover:text-slate-200 hover:border-white/10"
            }`}
            title="Solo this channel (mutes all non-solo channels)"
          >
            S
          </button>

          {/* Mute Button (M) */}
          <button
            id={`mute-${voice.id}`}
            onClick={onMuteToggle}
            className={`py-1.5 px-3 rounded-lg border font-bold text-xs transition-all duration-150 cursor-pointer ${
              voice.isMuted
                ? "bg-rose-500 border-rose-400 text-slate-950 shadow-md shadow-rose-500/10"
                : "bg-white/5 border-white/5 text-slate-400 hover:text-slate-200 hover:border-white/10"
            }`}
            title="Mute this channel"
          >
            M
          </button>
        </div>
      </div>
    </div>
  );
};
