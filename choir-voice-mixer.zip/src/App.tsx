import { useState, useEffect, FormEvent } from "react";
import { Hymn, Voice } from "./types";
import { player } from "./lib/audioEngine";
import { getAllHymns, saveHymn, deleteHymn } from "./lib/db";
import { generateDemoHymns } from "./lib/demoHymns";
import { downloadAndSynthesizeOnlineHymn, OnlineHymnItem } from "./lib/onlineRepository";
import { HymnList } from "./components/HymnList";
import { PlaybackControls } from "./components/PlaybackControls";
import { ChannelStrip } from "./components/ChannelStrip";
import { Dropzone } from "./components/Dropzone";
import { motion, AnimatePresence } from "motion/react";
import { Sliders, Volume2, Plus, Info, RefreshCw, X, Edit3, Music, AlertTriangle, Folder, ArrowRight, Check, Play } from "lucide-react";

const VOICE_ORDER: Record<string, number> = {
  soprano: 1,
  alto: 2,
  tenor: 3,
  bass: 4,
  base: 4,
  lead: 5,
  accompaniment: 6,
  organ: 7,
};

function getVoiceOrder(name: string): number {
  const norm = name.toLowerCase();
  for (const [key, value] of Object.entries(VOICE_ORDER)) {
    if (norm.includes(key)) {
      return value;
    }
  }
  return 99;
}

export default function App() {
  const [hymns, setHymns] = useState<Hymn[]>([]);
  const [activeHymn, setActiveHymn] = useState<Hymn | null>(null);

  const [activeFolder, setActiveFolder] = useState<string>(() => {
    return localStorage.getItem("vocalis_active_folder") || "offline-cache";
  });
  const [showFolderModal, setShowFolderModal] = useState(false);

  const handleSetActiveFolder = (folderName: string) => {
    const trimmed = folderName.trim() || "offline-cache";
    setActiveFolder(trimmed);
    localStorage.setItem("vocalis_active_folder", trimmed);
  };

  // Mirrors of player states
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLooping, setIsLooping] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [masterVolume, setMasterVolume] = useState(0.8);

  // UI state overlays
  const [isImporting, setIsImporting] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);
  const [isLoadingActiveHymn, setIsLoadingActiveHymn] = useState(false);
  const [loadProgress, setLoadProgress] = useState(0);

  const [showImportModal, setShowImportModal] = useState(false);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);
  const [movingHymnId, setMovingHymnId] = useState<string | null>(null);
  const [moveFolderInput, setMoveFolderInput] = useState<string>("");

  // Password ZIP support state
  const [pendingZipFile, setPendingZipFile] = useState<File | null>(null);
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [zipPasswordInput, setZipPasswordInput] = useState("");

  // Load hymns from DB on mount
  useEffect(() => {
    const initializeLibrary = async () => {
      try {
        let loaded = await getAllHymns();
        if (loaded.length === 0) {
          // If completely empty, seed with high-fidelity demos
          const demos = generateDemoHymns();
          for (const d of demos) {
            await saveHymn(d);
          }
          loaded = await getAllHymns();
        }
        setHymns(loaded);
        if (loaded.length > 0) {
          handleSelectHymn(loaded[0]);
        }
      } catch (err) {
        console.error("Library initialization failed:", err);
      }
    };
    initializeLibrary();
  }, []);

  // Sync callbacks with Web Audio Engine
  useEffect(() => {
    player.setCallbacks(
      () => {
        // State update callback
        const state = player.getPlaybackState();
        setIsPlaying(state.isPlaying);
        setIsLooping(state.isLooping);
        setDuration(state.duration);
        setMasterVolume(state.masterVolume);
      },
      () => {
        // Playback finished callback
        setIsPlaying(false);
        setCurrentTime(0);
      }
    );
  }, []);

  // Frame-accurate animation ticker to drive timeline scrubbers
  useEffect(() => {
    let animFrameId: number;
    const tick = () => {
      if (player.getPlaybackState().isPlaying) {
        setCurrentTime(player.getCurrentTime());
      }
      animFrameId = requestAnimationFrame(tick);
    };
    animFrameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animFrameId);
  }, []);

  // Keyboard shortcut (Spacebar) to play/pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        const activeEl = document.activeElement;
        if (
          activeEl &&
          (activeEl.tagName === "INPUT" ||
            activeEl.tagName === "TEXTAREA" ||
            (activeEl as HTMLElement).isContentEditable)
        ) {
          return;
        }
        e.preventDefault();
        if (activeHymn) {
          if (isPlaying) {
            player.pause();
          } else {
            player.play();
          }
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isPlaying, activeHymn]);

  // Handles active hymn loading with progress bars
  const handleSelectHymn = async (hymn: Hymn) => {
    setIsLoadingActiveHymn(true);
    setLoadProgress(0);
    try {
      player.stop();
      setActiveHymn(hymn);
      await player.loadHymn(hymn, (progress) => {
        setLoadProgress(progress);
      });
      // Capture calculated audio buffer durations
      const state = player.getPlaybackState();
      setDuration(state.duration);
      setCurrentTime(0);

      // Persist the actual calculated duration in IndexedDB and component state if it differs
      if (state.duration > 0 && Math.abs((hymn.duration || 0) - state.duration) > 0.5) {
        const updatedHymn = { ...hymn, duration: state.duration };
        await saveHymn(updatedHymn);
        setActiveHymn(updatedHymn);
        setHymns((prevHymns) =>
          prevHymns.map((h) => (h.id === hymn.id ? updatedHymn : h))
        );
      }
    } catch (err) {
      console.error("Failed to load chosen hymn track:", err);
    } finally {
      setIsLoadingActiveHymn(false);
    }
  };

  // Import ZIP package handler
  const handleFileAccepted = async (file: File) => {
    setIsImporting(true);
    setImportError(null);
    setImportSuccess(null);
    try {
      // Lazy load Zip parser dynamically to optimize bundle load sizes
      const { parseHymnZip } = await import("./lib/zipParser");
      const hymn = await parseHymnZip(file);
      hymn.folder = activeFolder;
      await saveHymn(hymn);

      const loaded = await getAllHymns();
      setHymns(loaded);

      setImportSuccess(`Imported "${hymn.name}" with ${hymn.voices.length} active parts!`);
      handleSelectHymn(hymn);

      setTimeout(() => {
        setShowImportModal(false);
        setImportSuccess(null);
      }, 2200);
    } catch (err: any) {
      if (err.isPasswordRequired) {
        setPendingZipFile(file);
        setShowPasswordPrompt(true);
        setImportError(null);
      } else {
        setImportError(err.message || "Failed to parse ZIP file.");
      }
    } finally {
      setIsImporting(false);
    }
  };

  const handlePasswordSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!pendingZipFile) return;
    setIsImporting(true);
    setImportError(null);
    setImportSuccess(null);
    try {
      const { parseHymnZip } = await import("./lib/zipParser");
      const hymn = await parseHymnZip(pendingZipFile, zipPasswordInput);
      hymn.folder = activeFolder;
      await saveHymn(hymn);

      const loaded = await getAllHymns();
      setHymns(loaded);

      setImportSuccess(`Imported "${hymn.name}" with ${hymn.voices.length} active parts!`);
      handleSelectHymn(hymn);

      // Clean up states
      setPendingZipFile(null);
      setZipPasswordInput("");
      setShowPasswordPrompt(false);

      setTimeout(() => {
        setShowImportModal(false);
        setImportSuccess(null);
      }, 2200);
    } catch (err: any) {
      setImportError(err.message || "Incorrect password or decryption error.");
    } finally {
      setIsImporting(false);
    }
  };

  const handleDeleteHymn = async (id: string) => {
    try {
      if (activeHymn?.id === id) {
        player.stop();
        setActiveHymn(null);
      }
      await deleteHymn(id);
      const loaded = await getAllHymns();
      setHymns(loaded);
      if (loaded.length > 0) {
        handleSelectHymn(loaded[0]);
      } else {
        setDuration(0);
        setCurrentTime(0);
      }
    } catch (err) {
      console.error("Delete track failed:", err);
    }
  };

  const handleMoveHymn = async (hymnId: string, destFolder: string) => {
    try {
      const target = hymns.find((h) => h.id === hymnId);
      if (!target) return;
      const updated = { ...target, folder: destFolder.trim() || "offline-cache" };
      await saveHymn(updated);
      
      const loaded = await getAllHymns();
      setHymns(loaded);
      
      if (activeHymn?.id === hymnId) {
        setActiveHymn(updated);
      }
      setMovingHymnId(null);
      setMoveFolderInput("");
    } catch (err) {
      console.error("Failed to move hymn:", err);
    }
  };

  const handleResetDemoCommit = async () => {
    setShowResetConfirmModal(false);
    player.stop();
    player.clearCache();
    setActiveHymn(null);

    const loaded = await getAllHymns();
    for (const h of loaded) {
      await deleteHymn(h.id);
    }

    const demos = generateDemoHymns();
    for (const d of demos) {
      await saveHymn(d);
    }

    const fresh = await getAllHymns();
    setHymns(fresh);
    if (fresh.length > 0) {
      handleSelectHymn(fresh[0]);
    }
  };

  // Modifies channel fader levels and pushes them into Audio Engine and DB state
  const handleVoiceVolume = async (voiceId: string, vol: number) => {
    if (!activeHymn) return;
    const updatedVoices = activeHymn.voices.map((v) => {
      if (v.id === voiceId) {
        // Automatically unmute if it was muted
        return { ...v, volume: vol, isMuted: false };
      }
      return v;
    });

    const updatedHymn = { ...activeHymn, voices: updatedVoices };
    player.updateActiveHymn(updatedHymn);
    player.updateAllVoiceGains();
    setActiveHymn(updatedHymn);
    await saveHymn(updatedHymn);
  };

  // Solo logic (exclusive listening state)
  const handleVoiceSolo = async (voiceId: string) => {
    if (!activeHymn) return;
    const updatedVoices = activeHymn.voices.map((v) => {
      if (v.id === voiceId) {
        return { ...v, isSolo: !v.isSolo };
      }
      return v;
    });

    const updatedHymn = { ...activeHymn, voices: updatedVoices };
    player.updateActiveHymn(updatedHymn);
    player.updateAllVoiceGains();
    setActiveHymn(updatedHymn);
    await saveHymn(updatedHymn);
  };

  // Mute logic (silence track state)
  const handleVoiceMute = async (voiceId: string) => {
    if (!activeHymn) return;
    const updatedVoices = activeHymn.voices.map((v) => {
      if (v.id === voiceId) {
        return { ...v, isMuted: !v.isMuted };
      }
      return v;
    });

    const updatedHymn = { ...activeHymn, voices: updatedVoices };
    player.updateActiveHymn(updatedHymn);
    player.updateAllVoiceGains();
    setActiveHymn(updatedHymn);
    await saveHymn(updatedHymn);
  };

  // Modifies channel pan levels and pushes them into Audio Engine and DB state
  const handleVoicePan = async (voiceId: string, pan: number) => {
    if (!activeHymn) return;
    const updatedVoices = activeHymn.voices.map((v) => {
      if (v.id === voiceId) {
        return { ...v, pan };
      }
      return v;
    });

    const updatedHymn = { ...activeHymn, voices: updatedVoices };
    player.updateActiveHymn(updatedHymn);
    const targetVoice = updatedVoices.find((v) => v.id === voiceId);
    if (targetVoice) {
      player.updateVoicePan(targetVoice);
    }
    setActiveHymn(updatedHymn);
    await saveHymn(updatedHymn);
  };

  const handleDownloadOnlineHymn = async (item: OnlineHymnItem, onProgress: (msg: string) => void) => {
    try {
      const downloadedHymn = await downloadAndSynthesizeOnlineHymn(item, onProgress);
      // Place it in the user's current folder
      downloadedHymn.folder = activeFolder;
      
      // Save it to IndexedDB
      await saveHymn(downloadedHymn);
      
      // Update state
      setHymns((prev) => [downloadedHymn, ...prev]);
      
      // Select the downloaded hymn immediately so the user can hear it!
      await handleSelectHymn(downloadedHymn);
    } catch (err) {
      console.error("Failed downloading and synthesizing online hymn:", err);
      throw err;
    }
  };

  const triggerRenameDialog = () => {
    if (!activeHymn) return;
    setRenameValue(activeHymn.name);
    setShowRenameModal(true);
  };

  const handleRenameCommit = async () => {
    if (!activeHymn || !renameValue.trim()) return;
    const updated = { ...activeHymn, name: renameValue.trim() };
    await saveHymn(updated);
    setActiveHymn(updated);
    
    // Reload list
    const loaded = await getAllHymns();
    setHymns(loaded);
    setShowRenameModal(false);
  };

  return (
    <div className="flex flex-col h-screen w-screen app-bg text-slate-100 overflow-hidden font-sans selection:bg-blue-500/30 selection:text-blue-200">
      
      {/* Header bar */}
      <header className="h-14 border-b border-white/5 bg-white/5 backdrop-blur-md px-6 flex items-center justify-between shrink-0 select-none">
        <div className="flex items-center gap-3">
          <div className="p-1.5 bg-blue-600 rounded-lg shadow-lg shadow-blue-600/30 text-white border border-blue-400/20">
            <Sliders className="h-4 w-4" />
          </div>
          <span className="font-display font-bold text-sm tracking-wide bg-clip-text text-transparent bg-gradient-to-r from-slate-100 via-blue-200 to-blue-100">
            VOCALIS • Choir Voice Mixer
          </span>
        </div>


      </header>

      {/* Main workspace layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Navigation */}
        <HymnList
          hymns={hymns}
          activeHymnId={activeHymn?.id || null}
          onSelectHymn={handleSelectHymn}
          onDeleteHymn={handleDeleteHymn}
          onAddClick={() => setShowImportModal(true)}
          onResetDemo={() => setShowResetConfirmModal(true)}
          activeFolder={activeFolder}
          onFolderClick={() => setShowFolderModal(true)}
          onDownloadOnlineHymn={handleDownloadOnlineHymn}
        />

        {/* Dashboard Workspace */}
        <main className="flex-1 overflow-y-auto bg-transparent px-8 py-6 flex flex-col gap-6 relative">
          
          {isLoadingActiveHymn ? (
            /* Loading State Backdrop */
            <div className="absolute inset-0 bg-[#05070a]/60 backdrop-blur-xl z-40 flex flex-col items-center justify-center gap-4">
              <RefreshCw className="h-8 w-8 text-blue-400 animate-spin" />
              <div className="flex flex-col items-center gap-1.5">
                <span className="font-semibold text-sm text-slate-200">
                  Decoding Audio Tracks
                </span>
                <div className="w-48 h-1.5 bg-white/5 rounded-full overflow-hidden border border-white/10">
                  <div
                    className="h-full bg-blue-500 rounded-full transition-all duration-300"
                    style={{ width: `${loadProgress}%` }}
                  />
                </div>
                <span className="text-[10px] font-mono text-slate-400">
                  {loadProgress}% complete
                </span>
              </div>
            </div>
          ) : null}

          {activeHymn ? (
            <div className="flex flex-col gap-6 max-w-7xl mx-auto w-full">
              
              {/* Playback & Seeker Control HUD */}
              <PlaybackControls
                name={activeHymn.name}
                isPlaying={isPlaying}
                isLooping={isLooping}
                currentTime={currentTime}
                duration={duration}
                masterVolume={masterVolume}
                onPlay={() => player.play()}
                onPause={() => player.pause()}
                onStop={() => player.stop()}
                onLoopToggle={() => player.setLooping(!isLooping)}
                onVolumeChange={(vol) => player.setMasterVolume(vol)}
                onSeek={(secs) => player.seek(secs)}
                onRename={triggerRenameDialog}
                lyrics={activeHymn.lyrics}
                music={activeHymn.music}
                arranger={activeHymn.arranger}
                info={activeHymn.info}
                tags={activeHymn.tags}
              />

              {/* Mixing board channel strips title */}
              <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                <Music className="h-4 w-4 text-blue-400" />
                <h3 className="font-display font-semibold text-slate-300 text-sm tracking-wide">
                  MIXER CONSOLE CHANNELS
                </h3>
              </div>

              {/* Grid of mixer strips */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <AnimatePresence mode="popLayout">
                  {[...activeHymn.voices]
                    .sort((a, b) => getVoiceOrder(a.name) - getVoiceOrder(b.name))
                    .map((voice, idx) => (
                      <motion.div
                        key={voice.id}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.3, delay: idx * 0.05 }}
                      >
                        <ChannelStrip
                          voice={voice}
                          onVolumeChange={(vol) => handleVoiceVolume(voice.id, vol)}
                          onMuteToggle={() => handleVoiceMute(voice.id)}
                          onSoloToggle={() => handleVoiceSolo(voice.id)}
                          onPanChange={(pan) => handleVoicePan(voice.id, pan)}
                          isPlaying={isPlaying}
                        />
                      </motion.div>
                    ))}
                </AnimatePresence>
              </div>
            </div>
          ) : (
            /* Blank state if no tracks are chosen */
            <div className="flex-1 flex flex-col items-center justify-center p-12 max-w-md mx-auto text-center gap-6">
              <div className="p-4 bg-white/5 rounded-3xl border border-white/10 text-slate-400 shadow-xl">
                <Music className="h-10 w-10 text-blue-400 animate-pulse" />
              </div>
              <div className="flex flex-col gap-1.5">
                <h2 className="font-display font-bold text-slate-200 text-lg">
                  No Track Selected
                </h2>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Select a hymn track from the sidebar to start practicing, or import a zipped choir pack to load custom multi-channel recordings.
                </p>
              </div>
              <button
                id="btn-blank-import"
                onClick={() => setShowImportModal(true)}
                className="py-2.5 px-5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs border border-blue-400/20 shadow-md shadow-blue-600/10 cursor-pointer"
              >
                Import ZIP Bundle
              </button>
            </div>
          )}
        </main>
      </div>

      {/* Footer statistics bar */}
      <footer className="h-10 border-t border-white/5 bg-white/5 px-6 flex items-center justify-between shrink-0 text-xs text-slate-500 select-none">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
          <span>All voices are synchronized</span>
        </div>
        
        <div className="font-mono text-[10px] tracking-wide flex items-center gap-4">
          <span>44100 Hz</span>
          <span>•</span>
          <span>32-bit float</span>
          <span>•</span>
          <span className="text-blue-400 font-semibold uppercase">
            {activeHymn ? `${activeHymn.voices.length} CHANNELS` : "0 CHANNELS"}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <Volume2 className="h-3.5 w-3.5" />
          <div className="w-16 h-1 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500"
              style={{ width: `${masterVolume * 100}%` }}
            />
          </div>
        </div>
      </footer>

      {/* --- POPUP OVERLAY MODAL: ZIP IMPORT --- */}
      <AnimatePresence>
        {showImportModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0b0c15]/95 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 w-full max-w-lg shadow-2xl relative"
            >
              <button
                id="close-import-modal"
                onClick={() => {
                  if (!isImporting) setShowImportModal(false);
                }}
                className="absolute top-4 right-4 p-1 rounded-xl text-slate-500 hover:text-slate-300 hover:bg-white/5 cursor-pointer"
                disabled={isImporting}
              >
                <X className="h-4 w-4" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-600/15 border border-blue-500/20 text-blue-400 rounded-2xl">
                  <Sliders className="h-5 w-5" />
                </div>
                <div className="flex flex-col text-left">
                  <h3 className="font-display font-bold text-slate-200 text-sm">
                    Import Choir Tracks
                  </h3>
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
                    ZIP Archive Bundle
                  </span>
                </div>
              </div>

              <Dropzone
                onFileAccepted={handleFileAccepted}
                isProcessing={isImporting}
                errorMsg={importError}
                successMsg={importSuccess}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- POPUP OVERLAY MODAL: RENAME HYMN --- */}
      <AnimatePresence>
        {showRenameModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0b0c15]/95 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 w-full max-w-sm shadow-2xl relative text-left"
            >
              <button
                id="close-rename-modal"
                onClick={() => setShowRenameModal(false)}
                className="absolute top-4 right-4 p-1 rounded-xl text-slate-500 hover:text-slate-300 hover:bg-white/5 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-600/15 border border-blue-500/20 text-blue-400 rounded-2xl">
                  <Edit3 className="h-4 w-4" />
                </div>
                <h3 className="font-display font-bold text-slate-200 text-sm">
                  Rename Hymn Track
                </h3>
              </div>

              <div className="space-y-4">
                <input
                  id="rename-hymn-input"
                  type="text"
                  value={renameValue}
                  onChange={(e) => setRenameValue(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  placeholder="Hymn Name"
                />
                
                <div className="flex gap-2 justify-end">
                  <button
                    id="rename-cancel"
                    onClick={() => setShowRenameModal(false)}
                    className="py-1.5 px-3 rounded-lg text-slate-400 hover:text-slate-200 font-semibold text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    id="rename-save"
                    onClick={handleRenameCommit}
                    className="py-1.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs cursor-pointer border border-blue-400/20 shadow-md shadow-blue-600/10"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- POPUP OVERLAY MODAL: ZIP PASSWORD PROMPT --- */}
      <AnimatePresence>
        {showPasswordPrompt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0b0c15]/95 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 w-full max-w-sm shadow-2xl relative text-left"
            >
              <button
                id="close-password-modal"
                onClick={() => {
                  setShowPasswordPrompt(false);
                  setPendingZipFile(null);
                  setZipPasswordInput("");
                }}
                className="absolute top-4 right-4 p-1 rounded-xl text-slate-500 hover:text-slate-300 hover:bg-white/5 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-yellow-600/15 border border-yellow-500/20 text-yellow-400 rounded-2xl">
                  <Info className="h-4 w-4" />
                </div>
                <h3 className="font-display font-bold text-slate-200 text-sm">
                  Password Required
                </h3>
              </div>

              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <p className="text-xs text-slate-400 leading-relaxed">
                  This ZIP archive is protected by a password. Please enter the password to decrypt and import the tracks.
                </p>

                <input
                  id="zip-password-input"
                  type="password"
                  value={zipPasswordInput}
                  onChange={(e) => setZipPasswordInput(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  placeholder="Enter archive password"
                  autoFocus
                  required
                />

                {importError && (
                  <div className="text-[11px] text-rose-400 bg-rose-500/10 border border-rose-500/20 px-3 py-2 rounded-xl">
                    {importError}
                  </div>
                )}
                
                <div className="flex gap-2 justify-end">
                  <button
                    id="password-cancel"
                    type="button"
                    onClick={() => {
                      setShowPasswordPrompt(false);
                      setPendingZipFile(null);
                      setZipPasswordInput("");
                    }}
                    className="py-1.5 px-3 rounded-lg text-slate-400 hover:text-slate-200 font-semibold text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    id="password-submit"
                    type="submit"
                    disabled={isImporting}
                    className="py-1.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs cursor-pointer border border-blue-400/20 shadow-md shadow-blue-600/10 flex items-center gap-1.5"
                  >
                    {isImporting ? "Decrypting..." : "Decrypt & Import"}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- POPUP OVERLAY MODAL: CONFIRM RESEED/RESET DEMOS --- */}
      <AnimatePresence>
        {showResetConfirmModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-xl z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0b0c15]/95 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 w-full max-w-sm shadow-2xl relative text-left"
            >
              <button
                id="close-reset-confirm-modal"
                onClick={() => setShowResetConfirmModal(false)}
                className="absolute top-4 right-4 p-1 rounded-xl text-slate-500 hover:text-slate-300 hover:bg-white/5 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-amber-600/15 border border-amber-500/20 text-amber-400 rounded-2xl">
                  <AlertTriangle className="h-4 w-4" />
                </div>
                <h3 className="font-display font-bold text-slate-200 text-sm">
                  Reseed Demo Hymns?
                </h3>
              </div>

              <div className="space-y-4">
                <p className="text-xs text-slate-400 leading-relaxed">
                  This action will erase all of your custom imported hymns and restore the default high-fidelity demo hymns. This cannot be undone.
                </p>

                <div className="flex gap-2 justify-end pt-2">
                  <button
                    id="reset-confirm-cancel"
                    onClick={() => setShowResetConfirmModal(false)}
                    className="py-1.5 px-3 rounded-lg text-slate-400 hover:text-slate-200 font-semibold text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    id="reset-confirm-proceed"
                    onClick={handleResetDemoCommit}
                    className="py-1.5 px-4 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs cursor-pointer border border-amber-400/20 shadow-md shadow-amber-600/10"
                  >
                    Reseed Library
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- POPUP OVERLAY MODAL: FOLDER EXPLORER / MANAGER --- */}
      <AnimatePresence>
        {showFolderModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-xl z-50 flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0b0c15]/95 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 w-full max-w-2xl shadow-2xl relative my-8 text-left flex flex-col max-h-[85vh]"
            >
              <button
                id="close-folder-modal"
                onClick={() => setShowFolderModal(false)}
                className="absolute top-4 right-4 p-1 rounded-xl text-slate-500 hover:text-slate-300 hover:bg-white/5 cursor-pointer z-10"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="flex items-center gap-3 mb-6 shrink-0">
                <div className="p-2 bg-blue-600/15 border border-blue-500/20 text-blue-400 rounded-2xl">
                  <Folder className="h-5 w-5" />
                </div>
                <div className="flex flex-col">
                  <h3 className="font-display font-bold text-slate-200 text-sm">
                    Folder Explorer & Manager
                  </h3>
                  <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">
                    Assign and Organize Your Hymns
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden flex-1">
                {/* Left Side: Folder Management and Dropzone */}
                <div className="flex flex-col gap-4 overflow-y-auto pr-1">
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3">
                    <span className="text-[10px] font-mono font-bold text-slate-400 tracking-wider uppercase block">
                      ASSIGN ACTIVE IMPORT FOLDER
                    </span>
                    <input
                      id="folder-manager-input"
                      type="text"
                      value={activeFolder}
                      onChange={(e) => handleSetActiveFolder(e.target.value)}
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-medium placeholder-slate-500"
                      placeholder="e.g. Sunday Service"
                    />
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      <span className="text-[9px] text-slate-500 font-mono flex items-center w-full mb-1">
                        Quick selection / Switch to folder:
                      </span>
                      {(Array.from(new Set(hymns.map(h => h.folder || "offline-cache"))) as string[]).map(folderName => {
                        const isActive = folderName === activeFolder;
                        return (
                          <button
                            key={folderName}
                            onClick={() => handleSetActiveFolder(folderName)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-mono font-semibold cursor-pointer transition-all ${
                              isActive
                                ? "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                                : "bg-white/5 text-slate-400 hover:bg-white/10 border border-transparent"
                            }`}
                          >
                            {folderName}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex-1 flex flex-col min-h-[180px]">
                    <span className="text-[10px] font-mono font-bold text-slate-400 tracking-wider uppercase mb-2 block">
                      DRAG & DROP ZIP HERE
                    </span>
                    <p className="text-[10px] text-slate-500 leading-relaxed mb-3">
                      Drop any zipped choir package here. It will automatically be decoded and saved into folder <strong className="text-blue-400 font-mono">"{activeFolder}"</strong>.
                    </p>
                    <div className="flex-1 min-h-[100px] flex">
                      <Dropzone
                        onFileAccepted={handleFileAccepted}
                        isProcessing={isImporting}
                        errorMsg={importError}
                        successMsg={importSuccess}
                      />
                    </div>
                  </div>
                </div>

                {/* Right Side: Folder Tree Explorer */}
                <div className="flex flex-col border border-white/10 bg-black/20 rounded-2xl p-4 overflow-y-auto">
                  <span className="text-[10px] font-mono font-bold text-slate-400 tracking-wider uppercase mb-3 block shrink-0">
                    DIRECTORY CONTENT TREE
                  </span>

                  <div className="space-y-4 flex-1 overflow-y-auto pr-1">
                    {(Array.from(new Set(hymns.map(h => h.folder || "offline-cache"))) as string[]).map(folderName => {
                      const hymnsInFolder = hymns.filter(h => (h.folder || "offline-cache") === folderName);
                      const isAssigned = folderName === activeFolder;
                      
                      return (
                        <div key={folderName} className="border border-white/5 rounded-xl overflow-hidden bg-white/5">
                          {/* Folder Header */}
                          <div className="flex items-center justify-between bg-white/5 px-3 py-2 border-b border-white/5">
                            <div className="flex items-center gap-2 overflow-hidden">
                              <Folder className={`h-4 w-4 shrink-0 ${isAssigned ? "text-blue-400" : "text-slate-500"}`} />
                              <span className="font-display font-bold text-xs text-slate-200 truncate">
                                {folderName}
                              </span>
                              {isAssigned && (
                                <span className="text-[8px] bg-blue-500/20 text-blue-300 font-bold px-1.5 py-0.2 rounded uppercase shrink-0">
                                  active
                                </span>
                              )}
                            </div>
                            <span className="text-[9px] font-mono text-slate-500 shrink-0">
                              {hymnsInFolder.length} items
                            </span>
                          </div>

                          {/* Hymns List inside Folder */}
                          <div className="divide-y divide-white/5">
                            {hymnsInFolder.length === 0 ? (
                              <div className="p-3 text-center text-[10px] text-slate-600 italic">
                                Folder is empty
                              </div>
                            ) : (
                              hymnsInFolder.map(hymn => {
                                const isActive = hymn.id === activeHymn?.id;
                                const isMoving = movingHymnId === hymn.id;

                                return (
                                  <div key={hymn.id} className="p-2.5 flex flex-col gap-2 transition-colors hover:bg-white/2">
                                    <div className="flex items-center justify-between gap-2">
                                      <button
                                        onClick={() => {
                                          handleSelectHymn(hymn);
                                        }}
                                        className="flex items-center gap-2 overflow-hidden text-left cursor-pointer group/item flex-1"
                                      >
                                        <Music className={`h-3.5 w-3.5 shrink-0 ${isActive ? "text-blue-400" : "text-slate-500 group-hover/item:text-slate-300"}`} />
                                        <span className={`text-xs font-semibold truncate ${isActive ? "text-blue-400" : "text-slate-300 group-hover/item:text-slate-100"}`}>
                                          {hymn.name}
                                        </span>
                                      </button>

                                      <div className="flex items-center gap-1.5 shrink-0">
                                        {!isMoving && (
                                          <button
                                            onClick={() => {
                                              setMovingHymnId(hymn.id);
                                              setMoveFolderInput(folderName);
                                            }}
                                            className="p-1 text-[10px] text-slate-500 hover:text-blue-400 hover:bg-white/5 rounded cursor-pointer flex items-center gap-0.5"
                                            title="Move/Re-assign folder"
                                          >
                                            <Folder className="h-3 w-3" />
                                            <span className="text-[9px] font-semibold">Move</span>
                                          </button>
                                        )}

                                        <button
                                          onClick={() => {
                                            if (confirm(`Delete ${hymn.name} permanently?`)) {
                                              handleDeleteHymn(hymn.id);
                                            }
                                          }}
                                          className="p-1 text-[10px] text-slate-500 hover:text-rose-400 hover:bg-white/5 rounded cursor-pointer"
                                          title="Delete"
                                        >
                                          <X className="h-3.5 w-3.5" />
                                        </button>
                                      </div>
                                    </div>

                                    {/* Inline move folder controls */}
                                    {isMoving && (
                                      <div className="flex gap-1.5 items-center bg-black/30 border border-white/5 rounded-xl p-2 animate-fadeIn">
                                        <input
                                          type="text"
                                          value={moveFolderInput}
                                          onChange={(e) => setMoveFolderInput(e.target.value)}
                                          className="flex-1 px-2 py-1 bg-white/5 border border-white/10 rounded-lg text-[10px] text-slate-200 focus:outline-none focus:border-blue-500"
                                          placeholder="Enter destination folder"
                                        />
                                        <button
                                          onClick={() => handleMoveHymn(hymn.id, moveFolderInput)}
                                          className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold text-[9px] cursor-pointer"
                                        >
                                          Move
                                        </button>
                                        <button
                                          onClick={() => setMovingHymnId(null)}
                                          className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-slate-400 text-[9px] cursor-pointer"
                                        >
                                          Cancel
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                );
                              })
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="pt-4 border-t border-white/5 flex justify-end shrink-0">
                <button
                  id="folder-manager-done"
                  onClick={() => setShowFolderModal(false)}
                  className="py-1.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs border border-blue-400/20 shadow-md shadow-blue-600/10 cursor-pointer transition-all"
                >
                  Close Explorer
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
