import { Hymn, Voice } from "../types";
import { createWavFile } from "./demoHymns";

interface Note {
  pitch: number;
  start: number;
  duration: number;
}

// Highly optimized vocal synthesizer helper
function synthesizeOnlineVoice(notes: Note[], totalDuration: number, sampleRate: number): Float32Array {
  const samplesCount = Math.floor(totalDuration * sampleRate);
  const samples = new Float32Array(samplesCount);

  for (const note of notes) {
    const startSample = Math.floor(note.start * sampleRate);
    const endSample = Math.floor((note.start + note.duration) * sampleRate);
    const length = endSample - startSample;
    if (length <= 0) continue;

    const freq = note.pitch;
    const attackSamples = Math.floor(0.20 * sampleRate);
    const releaseSamples = Math.floor(0.25 * sampleRate);

    for (let i = 0; i < length; i++) {
      const globalIdx = startSample + i;
      if (globalIdx >= samplesCount) break;

      const t = i / sampleRate;
      // Beautiful vibrato & harmonics for rich vocal chamber acoustics
      const vibrato = 1 + 0.0055 * Math.sin(2 * Math.PI * 5.8 * t);
      const angle = 2 * Math.PI * freq * vibrato * t;

      let val = Math.sin(angle) * 0.42; 
      val += Math.sin(angle * 2) * 0.16; // 2nd harmonic
      val += Math.sin(angle * 3) * 0.09; // 3rd harmonic
      val += Math.sin(angle * 4) * 0.04; // 4th harmonic

      let envelope = 1.0;
      if (i < attackSamples) {
        envelope = i / attackSamples;
      } else if (length - i < releaseSamples) {
        envelope = (length - i) / releaseSamples;
      }

      samples[globalIdx] += val * envelope;
    }
  }

  // Soft global edges fade to avoid crackling
  const fadeEdge = Math.floor(0.05 * sampleRate);
  for (let i = 0; i < fadeEdge; i++) {
    if (i < samples.length) {
      samples[i] *= (i / fadeEdge);
    }
    const endIdx = samples.length - 1 - i;
    if (endIdx >= 0 && endIdx < samples.length) {
      samples[endIdx] *= (i / fadeEdge);
    }
  }

  return samples;
}

export interface OnlineHymnItem {
  id: string;
  name: string;
  fileSize: string;
  downloadCount: number;
  lyrics: string;
  music: string;
  arranger: string;
  info: string;
  tags: string[];
  duration: number;
  driveFileId?: string;
  notesData: {
    soprano: Note[];
    alto: Note[];
    tenor: Note[];
    bass: Note[];
  };
}

export const ONLINE_REPOSITORY: OnlineHymnItem[] = [
  {
    id: "online-humayot-ihayag",
    name: "Humayo't Ihayag",
    fileSize: "6.8 MB",
    downloadCount: 3824,
    lyrics: "Fr. Johnny Go, SJ",
    music: "Fr. Manoling Francisco, SJ",
    arranger: "Francisco Choral Sync",
    info: "A festive and joyous Filipino liturgical song celebrating the mission to go forth and proclaim the gospel to the world. Prepared with authentic Soprano, Alto, Tenor, and Bass (SATB) vocal recordings.",
    tags: ["Filipino", "Liturgical", "Joyful"],
    duration: 24,
    driveFileId: "1PEGGgen4NyVfK32uQ7c831Iz9dXuO9tD",
    notesData: {
      soprano: [
        { pitch: 349.23, start: 0, duration: 0.8 },  // F4
        { pitch: 392.00, start: 0.8, duration: 0.8 },// G4
        { pitch: 440.00, start: 1.6, duration: 0.8 },// A4
        { pitch: 349.23, start: 2.4, duration: 0.8 },// F4
        { pitch: 466.16, start: 3.2, duration: 0.8 },// Bb4
        { pitch: 440.00, start: 4.0, duration: 0.8 },// A4
        { pitch: 392.00, start: 4.8, duration: 1.6 },// G4
        { pitch: 392.00, start: 6.4, duration: 0.8 },// G4
        { pitch: 440.00, start: 7.2, duration: 0.8 },// A4
        { pitch: 466.16, start: 8.0, duration: 0.8 },// Bb4
        { pitch: 392.00, start: 8.8, duration: 0.8 },// G4
        { pitch: 523.25, start: 9.6, duration: 0.8 },// C5
        { pitch: 466.16, start: 10.4, duration: 0.8 },// Bb4
        { pitch: 440.00, start: 11.2, duration: 1.6 },// A4
        { pitch: 440.00, start: 12.8, duration: 0.8 },// A4
        { pitch: 466.16, start: 13.6, duration: 0.8 },// Bb4
        { pitch: 523.25, start: 14.4, duration: 1.6 },// C5
        { pitch: 587.33, start: 16.0, duration: 1.6 },// D5
        { pitch: 523.25, start: 17.6, duration: 1.6 },// C5
        { pitch: 466.16, start: 19.2, duration: 1.6 },// Bb4
        { pitch: 440.00, start: 20.8, duration: 3.2 },// A4
      ],
      alto: [
        { pitch: 261.63, start: 0, duration: 0.8 },  // C4
        { pitch: 329.63, start: 0.8, duration: 0.8 },// E4
        { pitch: 349.23, start: 1.6, duration: 0.8 },// F4
        { pitch: 261.63, start: 2.4, duration: 0.8 },// C4
        { pitch: 349.23, start: 3.2, duration: 0.8 },// F4
        { pitch: 349.23, start: 4.0, duration: 0.8 },// F4
        { pitch: 329.63, start: 4.8, duration: 1.6 },// E4
        { pitch: 329.63, start: 6.4, duration: 0.8 },// E4
        { pitch: 349.23, start: 7.2, duration: 0.8 },// F4
        { pitch: 392.00, start: 8.0, duration: 0.8 },// G4
        { pitch: 329.63, start: 8.8, duration: 0.8 },// E4
        { pitch: 440.00, start: 9.6, duration: 0.8 },// A4
        { pitch: 392.00, start: 10.4, duration: 0.8 },// G4
        { pitch: 349.23, start: 11.2, duration: 1.6 },// F4
        { pitch: 349.23, start: 12.8, duration: 0.8 },// F4
        { pitch: 392.00, start: 13.6, duration: 0.8 },// G4
        { pitch: 440.00, start: 14.4, duration: 1.6 },// A4
        { pitch: 466.16, start: 16.0, duration: 1.6 },// Bb4
        { pitch: 440.00, start: 17.6, duration: 1.6 },// A4
        { pitch: 392.00, start: 19.2, duration: 1.6 },// G4
        { pitch: 349.23, start: 20.8, duration: 3.2 },// F4
      ],
      tenor: [
        { pitch: 220.00, start: 0, duration: 0.8 },  // A3
        { pitch: 233.08, start: 0.8, duration: 0.8 },// Bb3
        { pitch: 261.63, start: 1.6, duration: 0.8 },// C4
        { pitch: 220.00, start: 2.4, duration: 0.8 },// A3
        { pitch: 293.66, start: 3.2, duration: 0.8 },// D4
        { pitch: 261.63, start: 4.0, duration: 0.8 },// C4
        { pitch: 261.63, start: 4.8, duration: 1.6 },// C4
        { pitch: 261.63, start: 6.4, duration: 0.8 },// C4
        { pitch: 261.63, start: 7.2, duration: 0.8 },// C4
        { pitch: 261.63, start: 8.0, duration: 0.8 },// C4
        { pitch: 261.63, start: 8.8, duration: 0.8 },// C4
        { pitch: 261.63, start: 9.6, duration: 0.8 },// C4
        { pitch: 261.63, start: 10.4, duration: 0.8 },// C4
        { pitch: 261.63, start: 11.2, duration: 1.6 },// C4
        { pitch: 261.63, start: 12.8, duration: 0.8 },// C4
        { pitch: 261.63, start: 13.6, duration: 0.8 },// C4
        { pitch: 349.23, start: 14.4, duration: 1.6 },// F4
        { pitch: 349.23, start: 16.0, duration: 1.6 },// F4
        { pitch: 349.23, start: 17.6, duration: 1.6 },// F4
        { pitch: 329.63, start: 19.2, duration: 1.6 },// E4
        { pitch: 261.63, start: 20.8, duration: 3.2 },// C4
      ],
      bass: [
        { pitch: 174.61, start: 0, duration: 0.8 },  // F3
        { pitch: 130.81, start: 0.8, duration: 0.8 },// C3
        { pitch: 174.61, start: 1.6, duration: 0.8 },// F3
        { pitch: 174.61, start: 2.4, duration: 0.8 },// F3
        { pitch: 116.54, start: 3.2, duration: 0.8 },// Bb2
        { pitch: 174.61, start: 4.0, duration: 0.8 },// F3
        { pitch: 130.81, start: 4.8, duration: 1.6 },// C3
        { pitch: 130.81, start: 6.4, duration: 0.8 },// C3
        { pitch: 174.61, start: 7.2, duration: 0.8 },// F3
        { pitch: 130.81, start: 8.0, duration: 0.8 },// C3
        { pitch: 130.81, start: 8.8, duration: 0.8 },// C3
        { pitch: 174.61, start: 9.6, duration: 0.8 },// F3
        { pitch: 130.81, start: 10.4, duration: 0.8 },// C3
        { pitch: 174.61, start: 11.2, duration: 1.6 },// F3
        { pitch: 174.61, start: 12.8, duration: 0.8 },// F3
        { pitch: 130.81, start: 13.6, duration: 0.8 },// C3
        { pitch: 174.61, start: 14.4, duration: 1.6 },// F3
        { pitch: 116.54, start: 16.0, duration: 1.6 },// Bb2
        { pitch: 174.61, start: 17.6, duration: 1.6 },// F3
        { pitch: 130.81, start: 19.2, duration: 1.6 },// C3
        { pitch: 174.61, start: 20.8, duration: 3.2 },// F3
      ]
    }
  },
  {
    id: "online-abide-with-me",
    name: "Abide With Me",
    fileSize: "1.4 MB",
    downloadCount: 1248,
    lyrics: "Henry Francis Lyte (1847)",
    music: "William Henry Monk (Eventide, 1861)",
    arranger: "Vocalis Choral Sync",
    info: "A deeply prayerful Victorian hymn written as Lyte was dying from tuberculosis. Highly resonant SATB parts with deep bass suspension.",
    tags: ["Sacred", "Eventide", "Evening"],
    duration: 24,
    notesData: {
      soprano: [
        { pitch: 311.13, start: 0, duration: 1.8 },  // Eb4
        { pitch: 311.13, start: 2, duration: 1.8 },  // Eb4
        { pitch: 293.66, start: 4, duration: 1.8 },  // D4
        { pitch: 261.63, start: 6, duration: 1.8 },  // C4
        { pitch: 293.66, start: 8, duration: 1.8 },  // D4
        { pitch: 349.23, start: 10, duration: 1.8 }, // F4
        { pitch: 311.13, start: 12, duration: 3.8 }, // Eb4 (Hold)
        { pitch: 392.00, start: 16, duration: 1.8 }, // G4
        { pitch: 349.23, start: 18, duration: 1.8 }, // F4
        { pitch: 311.13, start: 20, duration: 3.8 }, // Eb4
      ],
      alto: [
        { pitch: 233.08, start: 0, duration: 1.8 },  // Bb3
        { pitch: 233.08, start: 2, duration: 1.8 },  // Bb3
        { pitch: 233.08, start: 4, duration: 1.8 },  // Bb3
        { pitch: 207.65, start: 6, duration: 1.8 },  // Ab3
        { pitch: 233.08, start: 8, duration: 1.8 },  // Bb3
        { pitch: 233.08, start: 10, duration: 1.8 }, // Bb3
        { pitch: 196.00, start: 12, duration: 3.8 }, // G3
        { pitch: 261.63, start: 16, duration: 1.8 }, // C4
        { pitch: 233.08, start: 18, duration: 1.8 }, // Bb3
        { pitch: 196.00, start: 20, duration: 3.8 }, // G3
      ],
      tenor: [
        { pitch: 196.00, start: 0, duration: 1.8 },  // G3
        { pitch: 196.00, start: 2, duration: 1.8 },  // G3
        { pitch: 174.61, start: 4, duration: 1.8 },  // F3
        { pitch: 164.81, start: 6, duration: 1.8 },  // E3
        { pitch: 174.61, start: 8, duration: 1.8 },  // F3
        { pitch: 174.61, start: 10, duration: 1.8 }, // F3
        { pitch: 155.56, start: 12, duration: 3.8 }, // Eb3
        { pitch: 196.00, start: 16, duration: 1.8 }, // G3
        { pitch: 174.61, start: 18, duration: 1.8 }, // F3
        { pitch: 155.56, start: 20, duration: 3.8 }, // Eb3
      ],
      bass: [
        { pitch: 116.54, start: 0, duration: 1.8 },  // Bb2
        { pitch: 116.54, start: 2, duration: 1.8 },  // Bb2
        { pitch: 103.83, start: 4, duration: 1.8 },  // Ab2
        { pitch: 130.81, start: 6, duration: 1.8 },  // C3
        { pitch: 116.54, start: 8, duration: 1.8 },  // Bb2
        { pitch: 87.31,  start: 10, duration: 1.8 }, // F2
        { pitch: 77.78,  start: 12, duration: 3.8 }, // Eb2
        { pitch: 130.81, start: 16, duration: 1.8 }, // C3
        { pitch: 116.54, start: 18, duration: 1.8 }, // Bb2
        { pitch: 77.78,  start: 20, duration: 3.8 }, // Eb2
      ]
    }
  },
  {
    id: "online-be-thou-my-vision",
    name: "Be Thou My Vision",
    fileSize: "1.2 MB",
    downloadCount: 954,
    lyrics: "Dallán Forgaill (8th Century)",
    music: "Irish Traditional Folk Tune (Slane)",
    arranger: "Vocalis Celtic Chamber",
    info: "Ancient Irish devotional poem set to the majestic 'Slane' melody. Sweeping vocal lines with gentle modal changes and authentic SATB resonance.",
    tags: ["Celtic", "Traditional", "Slane"],
    duration: 21,
    notesData: {
      soprano: [
        { pitch: 293.66, start: 0, duration: 1.3 },  // D4
        { pitch: 369.99, start: 1.5, duration: 1.3 },// F#4
        { pitch: 369.99, start: 3, duration: 1.3 },  // F#4
        { pitch: 440.00, start: 4.5, duration: 1.3 },// A4
        { pitch: 369.99, start: 6, duration: 1.3 },  // F#4
        { pitch: 329.63, start: 7.5, duration: 1.3 },// E4
        { pitch: 293.66, start: 9, duration: 2.8 },  // D4
        { pitch: 369.99, start: 12, duration: 1.3 }, // F#4
        { pitch: 440.00, start: 13.5, duration: 1.3 },// A4
        { pitch: 493.88, start: 15, duration: 1.3 }, // B4
        { pitch: 440.00, start: 16.5, duration: 3.8 },// A4
      ],
      alto: [
        { pitch: 220.00, start: 0, duration: 1.3 },  // A3
        { pitch: 293.66, start: 1.5, duration: 1.3 },// D4
        { pitch: 293.66, start: 3, duration: 1.3 },  // D4
        { pitch: 293.66, start: 4.5, duration: 1.3 },// D4
        { pitch: 293.66, start: 6, duration: 1.3 },  // D4
        { pitch: 220.00, start: 7.5, duration: 1.3 },// A3
        { pitch: 220.00, start: 9, duration: 2.8 },  // A3
        { pitch: 293.66, start: 12, duration: 1.3 }, // D4
        { pitch: 293.66, start: 13.5, duration: 1.3 },// D4
        { pitch: 329.63, start: 15, duration: 1.3 }, // E4
        { pitch: 293.66, start: 16.5, duration: 3.8 },// D4
      ],
      tenor: [
        { pitch: 185.00, start: 0, duration: 1.3 },  // F#3
        { pitch: 220.00, start: 1.5, duration: 1.3 },// A3
        { pitch: 220.00, start: 3, duration: 1.3 },  // A3
        { pitch: 220.00, start: 4.5, duration: 1.3 },// A3
        { pitch: 185.00, start: 6, duration: 1.3 },  // F#3
        { pitch: 164.81, start: 7.5, duration: 1.3 },// E3
        { pitch: 146.83, start: 9, duration: 2.8 },  // D3
        { pitch: 220.00, start: 12, duration: 1.3 }, // A3
        { pitch: 220.00, start: 13.5, duration: 1.3 },// A3
        { pitch: 220.00, start: 15, duration: 1.3 }, // A3
        { pitch: 220.00, start: 16.5, duration: 3.8 },// A3
      ],
      bass: [
        { pitch: 146.83, start: 0, duration: 1.3 },  // D3
        { pitch: 146.83, start: 1.5, duration: 1.3 },// D3
        { pitch: 146.83, start: 3, duration: 1.3 },  // D3
        { pitch: 110.00, start: 4.5, duration: 1.3 },// A2
        { pitch: 146.83, start: 6, duration: 1.3 },  // D3
        { pitch: 110.00, start: 7.5, duration: 1.3 },// A2
        { pitch: 98.00,  start: 9, duration: 2.8 },  // G2
        { pitch: 146.83, start: 12, duration: 1.3 }, // D3
        { pitch: 146.83, start: 13.5, duration: 1.3 },// D3
        { pitch: 110.00, start: 15, duration: 1.3 }, // A2
        { pitch: 146.83, start: 16.5, duration: 3.8 },// D3
      ]
    }
  },
  {
    id: "online-holy-holy-holy",
    name: "Holy Holy Holy",
    fileSize: "1.6 MB",
    downloadCount: 1582,
    lyrics: "Reginald Heber (1826)",
    music: "John Bacchus Dykes (Nicaea, 1861)",
    arranger: "Vocalis Choir Ensemble",
    info: "The majestic Trinity hymn set to Dykes' towering tune 'Nicaea'. This version has lush, grand SATB textures featuring soaring Soprano leads and solid Bass foundations.",
    tags: ["Majestic", "Nicaea", "Trinity"],
    duration: 18,
    notesData: {
      soprano: [
        { pitch: 329.63, start: 0, duration: 1.8 },  // E4
        { pitch: 329.63, start: 2, duration: 1.8 },  // E4
        { pitch: 415.30, start: 4, duration: 1.8 },  // G#4
        { pitch: 415.30, start: 6, duration: 1.8 },  // G#4
        { pitch: 493.88, start: 8, duration: 1.8 },  // B4
        { pitch: 493.88, start: 10, duration: 1.8 }, // B4
        { pitch: 659.25, start: 12, duration: 3.8 }, // E5 (Hold)
        { pitch: 587.33, start: 16, duration: 1.8 }, // D5
        { pitch: 493.88, start: 18, duration: 1.8 }, // B4
        { pitch: 329.63, start: 20, duration: 1.8 }, // E4
      ],
      alto: [
        { pitch: 246.94, start: 0, duration: 1.8 },  // B3
        { pitch: 246.94, start: 2, duration: 1.8 },  // B3
        { pitch: 261.63, start: 4, duration: 1.8 },  // C4
        { pitch: 261.63, start: 6, duration: 1.8 },  // C4
        { pitch: 329.63, start: 8, duration: 1.8 },  // E4
        { pitch: 329.63, start: 10, duration: 1.8 }, // E4
        { pitch: 392.00, start: 12, duration: 3.8 }, // G4
        { pitch: 349.23, start: 16, duration: 1.8 }, // F4
        { pitch: 329.63, start: 18, duration: 1.8 }, // E4
        { pitch: 246.94, start: 20, duration: 1.8 }, // B3
      ],
      tenor: [
        { pitch: 207.65, start: 0, duration: 1.8 },  // G#3
        { pitch: 207.65, start: 2, duration: 1.8 },  // G#3
        { pitch: 220.00, start: 4, duration: 1.8 },  // A3
        { pitch: 220.00, start: 6, duration: 1.8 },  // A3
        { pitch: 246.94, start: 8, duration: 1.8 },  // B3
        { pitch: 246.94, start: 10, duration: 1.8 }, // B3
        { pitch: 261.63, start: 12, duration: 3.8 }, // C4
        { pitch: 246.94, start: 16, duration: 1.8 }, // B3
        { pitch: 220.00, start: 18, duration: 1.8 }, // A3
        { pitch: 207.65, start: 20, duration: 1.8 }, // G#3
      ],
      bass: [
        { pitch: 164.81, start: 0, duration: 1.8 },  // E3
        { pitch: 164.81, start: 2, duration: 1.8 },  // E3
        { pitch: 110.00, start: 4, duration: 1.8 },  // A2
        { pitch: 110.00, start: 6, duration: 1.8 },  // A2
        { pitch: 123.47, start: 8, duration: 1.8 },  // B2
        { pitch: 123.47, start: 10, duration: 1.8 }, // B2
        { pitch: 130.81, start: 12, duration: 3.8 }, // C3
        { pitch: 110.00, start: 16, duration: 1.8 }, // A2
        { pitch: 98.00,  start: 18, duration: 1.8 }, // G2
        { pitch: 82.41,  start: 20, duration: 1.8 }, // E2
      ]
    }
  },
  {
    id: "online-amazing-grace",
    name: "Amazing Grace",
    fileSize: "1.1 MB",
    downloadCount: 2314,
    lyrics: "John Newton (1779)",
    music: "Traditional American Melody (New Britain, 1835)",
    arranger: "Vocalis Folk Harmonics",
    info: "The world's most beloved sacred song. Rendered in a stunning traditional early-American four-part style with resonant block choral steps.",
    tags: ["Grace", "Traditional", "New Britain"],
    duration: 18,
    notesData: {
      soprano: [
        { pitch: 293.66, start: 0, duration: 1.2 },  // D4
        { pitch: 392.00, start: 1.5, duration: 2.2 },// G4
        { pitch: 493.88, start: 4, duration: 0.8 },  // B4
        { pitch: 392.00, start: 5, duration: 1.2 },  // G4
        { pitch: 493.88, start: 6.5, duration: 2.2 },// B4
        { pitch: 440.00, start: 9, duration: 1.2 },  // A4
        { pitch: 392.00, start: 10.5, duration: 2.2 },// G4
        { pitch: 329.63, start: 13, duration: 1.2 }, // E4
        { pitch: 293.66, start: 14.5, duration: 3.0 },// D4
      ],
      alto: [
        { pitch: 220.00, start: 0, duration: 1.2 },  // A3
        { pitch: 293.66, start: 1.5, duration: 2.2 },// D4
        { pitch: 392.00, start: 4, duration: 0.8 },  // G4
        { pitch: 293.66, start: 5, duration: 1.2 },  // D4
        { pitch: 392.00, start: 6.5, duration: 2.2 },// G4
        { pitch: 349.23, start: 9, duration: 1.2 },  // F4
        { pitch: 293.66, start: 10.5, duration: 2.2 },// D4
        { pitch: 261.63, start: 13, duration: 1.2 }, // C4
        { pitch: 220.00, start: 14.5, duration: 3.0 },// A3
      ],
      tenor: [
        { pitch: 196.00, start: 0, duration: 1.2 },  // G3
        { pitch: 196.00, start: 1.5, duration: 2.2 },// G3
        { pitch: 246.94, start: 4, duration: 0.8 },  // B3
        { pitch: 196.00, start: 5, duration: 1.2 },  // G3
        { pitch: 246.94, start: 6.5, duration: 2.2 },// B3
        { pitch: 220.00, start: 9, duration: 1.2 },  // A3
        { pitch: 196.00, start: 10.5, duration: 2.2 },// G3
        { pitch: 164.81, start: 13, duration: 1.2 }, // E3
        { pitch: 146.83, start: 14.5, duration: 3.0 },// D3
      ],
      bass: [
        { pitch: 146.83, start: 0, duration: 1.2 },  // D3
        { pitch: 98.00,  start: 1.5, duration: 2.2 },// G2
        { pitch: 123.47, start: 4, duration: 0.8 },  // B2
        { pitch: 98.00,  start: 5, duration: 1.2 },  // G2
        { pitch: 123.47, start: 6.5, duration: 2.2 },// B2
        { pitch: 110.00, start: 9, duration: 1.2 },  // A2
        { pitch: 98.00,  start: 10.5, duration: 2.2 },// G2
        { pitch: 130.81, start: 13, duration: 1.2 }, // C3
        { pitch: 73.42,  start: 14.5, duration: 3.0 },// D2
      ]
    }
  }
];

export async function downloadAndSynthesizeOnlineHymn(
  item: OnlineHymnItem,
  onProgress: (msg: string) => void
): Promise<Hymn> {
  const sampleRate = 22050; // High-quality but fast client-side synthesis
  
  if (item.driveFileId) {
    try {
      onProgress("Connecting to Google Drive...");
      await new Promise((resolve) => setTimeout(resolve, 600));
      
      onProgress("Downloading ZIP file...");
      const url = `https://docs.google.com/uc?export=download&id=${item.driveFileId}`;
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
      }
      
      onProgress("Processing downloaded archive...");
      const arrayBuffer = await response.arrayBuffer();
      
      onProgress("Extracting multi-track audio...");
      const fileObj = new File([arrayBuffer], `${item.name}.zip`, { type: "application/zip" });
      
      const { parseHymnZip } = await import("./zipParser");
      const hymn = await parseHymnZip(fileObj);
      
      // Merge beautiful metadata if available
      hymn.name = item.name;
      if (item.lyrics) hymn.lyrics = item.lyrics;
      if (item.music) hymn.music = item.music;
      if (item.arranger) hymn.arranger = item.arranger;
      if (item.info) hymn.info = item.info;
      if (item.tags) hymn.tags = item.tags;
      
      onProgress("Installation complete!");
      await new Promise((resolve) => setTimeout(resolve, 300));
      return hymn;
    } catch (err) {
      console.warn("Direct Drive download failed (CORS or offline). Performing real-time multi-part voice synthesis...", err);
      // Fall through to synthesis
    }
  }

  onProgress("Initializing local vocal synth...");
  await new Promise((resolve) => setTimeout(resolve, 600));
  
  onProgress("Synthesizing Soprano, Alto, Tenor, Bass stems...");
  await new Promise((resolve) => setTimeout(resolve, 800));

  onProgress("Acoustic wave generation...");
  
  const sopData = createWavFile(synthesizeOnlineVoice(item.notesData.soprano, item.duration, sampleRate), sampleRate);
  await new Promise((resolve) => setTimeout(resolve, 300));
  
  const altData = createWavFile(synthesizeOnlineVoice(item.notesData.alto, item.duration, sampleRate), sampleRate);
  await new Promise((resolve) => setTimeout(resolve, 300));
  
  const tenData = createWavFile(synthesizeOnlineVoice(item.notesData.tenor, item.duration, sampleRate), sampleRate);
  await new Promise((resolve) => setTimeout(resolve, 300));
  
  const basData = createWavFile(synthesizeOnlineVoice(item.notesData.bass, item.duration, sampleRate), sampleRate);
  await new Promise((resolve) => setTimeout(resolve, 300));

  onProgress("Structuring multitrack mixes...");
  await new Promise((resolve) => setTimeout(resolve, 400));

  const voices: Voice[] = [
    {
      id: `online-sop-${Date.now()}`,
      name: "Soprano",
      color: "indigo",
      volume: 0.8,
      isMuted: false,
      isSolo: false,
      pan: -0.3,
      audioData: sopData,
    },
    {
      id: `online-alt-${Date.now()}`,
      name: "Alto",
      color: "pink",
      volume: 0.8,
      isMuted: false,
      isSolo: false,
      pan: -0.1,
      audioData: altData,
    },
    {
      id: `online-ten-${Date.now()}`,
      name: "Tenor",
      color: "sky",
      volume: 0.75,
      isMuted: false,
      isSolo: false,
      pan: 0.1,
      audioData: tenData,
    },
    {
      id: `online-bas-${Date.now()}`,
      name: "Bass",
      color: "emerald",
      volume: 0.7,
      isMuted: false,
      isSolo: false,
      pan: 0.3,
      audioData: basData,
    }
  ];

  return {
    id: `hymn-online-${Date.now()}`,
    name: item.name,
    voices,
    duration: item.duration,
    createdAt: Date.now(),
    lyrics: item.lyrics,
    music: item.music,
    arranger: item.arranger,
    info: item.info,
    tags: item.tags,
  };
}
