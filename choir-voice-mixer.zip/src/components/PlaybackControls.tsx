import React from "react";
import { Play, Pause, Square, Volume2, VolumeX, Repeat, MoreVertical } from "lucide-react";

interface PlaybackControlsProps {
  name: string;
  isPlaying: boolean;
  isLooping: boolean;
  currentTime: number;
  duration: number;
  masterVolume: number;
  onPlay: () => void;
  onPause: () => void;
  onStop: () => void;
  onLoopToggle: () => void;
  onVolumeChange: (vol: number) => void;
  onSeek: (seconds: number) => void;
  onRename: () => void;
  lyrics?: string;
  music?: string;
  arranger?: string;
  info?: string;
  tags?: string[];
}

export const PlaybackControls: React.FC<PlaybackControlsProps> = ({
  name,
  isPlaying,
  isLooping,
  currentTime,
  duration,
  masterVolume,
  onPlay,
  onPause,
  onStop,
  onLoopToggle,
  onVolumeChange,
  onSeek,
  onRename,
  lyrics,
  music,
  arranger,
  info,
  tags,
}) => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleScrub = (e: React.ChangeEvent<HTMLInputElement>) => {
    onSeek(parseFloat(e.target.value));
  };

  return (
    <div className="glass-panel rounded-3xl p-6 shadow-2xl text-left relative overflow-hidden">
      {/* Top Header with Menu */}
      <div className="flex items-center justify-between mb-4">
        <h1 className="font-display font-bold text-slate-100 text-2xl tracking-tight cursor-pointer hover:text-blue-400 transition-colors" onClick={onRename} title="Rename Hymn">
          {name}
        </h1>
        <button
          id="btn-hymn-actions"
          onClick={onRename}
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-white/5 cursor-pointer"
          title="Rename Hymn"
        >
          <MoreVertical className="h-5 w-5" />
        </button>
      </div>

      {/* Metadata Section */}
      {(lyrics || music || arranger || info || (tags && tags.length > 0)) && (
        <div className="mb-6 border-b border-white/5 pb-4 space-y-1.5 text-slate-300">
          {lyrics && (
            <div className="text-xs">
              <span className="font-bold">Lyrics:</span> {lyrics}
            </div>
          )}
          {music && (
            <div className="text-xs">
              <span className="font-bold">Music:</span> {music}
            </div>
          )}
          {arranger && (
            <div className="text-xs">
              <span className="font-bold">Arranger:</span> {arranger}
            </div>
          )}
          {info && (
            <div className="text-xs italic text-slate-400 pt-0.5">
              {info}
            </div>
          )}
          {tags && tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-2">
              {tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2.5 py-0.5 bg-blue-500/10 border border-blue-500/15 rounded-full text-[10px] text-blue-300 font-mono tracking-wide"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Main Controls Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center mb-6">
        {/* Playback Buttons (Cols 1-5) */}
        <div className="lg:col-span-5 flex items-center gap-3">
          {/* Play Card */}
          <button
            id="control-play"
            onClick={onPlay}
            className={`flex-1 flex flex-col items-center justify-center p-4 rounded-2xl cursor-pointer border transition-all duration-150 ${
              isPlaying
                ? "bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/30"
                : "bg-white/5 border-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/10"
            }`}
          >
            <Play className={`h-6 w-6 ${isPlaying ? "fill-white" : ""}`} />
            <span className="text-[10px] font-bold tracking-wider mt-2 uppercase font-display">
              PLAY
            </span>
          </button>

          {/* Pause Card */}
          <button
            id="control-pause"
            onClick={onPause}
            className={`flex-1 flex flex-col items-center justify-center p-4 rounded-2xl cursor-pointer border transition-all duration-150 ${
              !isPlaying && currentTime > 0
                ? "bg-white/15 border-white/10 text-white shadow-lg shadow-black/10"
                : "bg-white/5 border-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/10"
            }`}
          >
            <Pause className="h-6 w-6" />
            <span className="text-[10px] font-bold tracking-wider mt-2 uppercase font-display">
              PAUSE
            </span>
          </button>

          {/* Stop Card */}
          <button
            id="control-stop"
            onClick={onStop}
            className="flex-1 flex flex-col items-center justify-center p-4 rounded-2xl cursor-pointer border bg-white/5 border-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/10 transition-all duration-150"
          >
            <Square className="h-6 w-6 fill-transparent hover:fill-slate-200 transition-colors" />
            <span className="text-[10px] font-bold tracking-wider mt-2 uppercase font-display">
              STOP
            </span>
          </button>

          {/* Loop Card */}
          <button
            id="control-loop"
            onClick={onLoopToggle}
            className={`flex-none flex flex-col items-center justify-center p-4 w-16 rounded-2xl cursor-pointer border transition-all duration-150 ${
              isLooping
                ? "bg-blue-500/20 border-blue-500/30 text-blue-400 shadow-md shadow-blue-500/5"
                : "bg-white/5 border-white/5 text-slate-400 hover:text-slate-200 hover:bg-white/10"
            }`}
            title="Toggle Seamless Loop"
          >
            <Repeat className="h-6 w-6" />
            <span className="text-[10px] font-bold tracking-wider mt-2 uppercase font-display">
              {isLooping ? "LOOP" : "ONCE"}
            </span>
          </button>
        </div>

        {/* Time Counters (Cols 6-8) */}
        <div className="lg:col-span-3 flex flex-col justify-center items-center lg:items-start text-center lg:text-left">
          <div className="flex items-baseline gap-1">
            <span className="font-mono text-3xl font-semibold text-slate-100 tracking-tight">
              {formatTime(currentTime)}
            </span>
            <span className="font-mono text-sm text-slate-500">
              / {formatTime(duration)}
            </span>
          </div>
          <span className="text-[9px] font-mono font-semibold tracking-widest text-slate-500 mt-1 uppercase">
            CURRENT TIME / DURATION
          </span>
        </div>

        {/* Master Volume Control (Cols 9-12) */}
        <div className="lg:col-span-4 bg-white/5 border border-white/5 rounded-2xl p-4 flex flex-col">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[9px] font-mono font-semibold tracking-wider text-slate-500 uppercase">
              MASTER VOLUME
            </span>
            <span className="font-mono text-xs text-slate-300 font-bold">
              {Math.round(masterVolume * 100)}%
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              id="btn-master-mute"
              onClick={() => onVolumeChange(masterVolume > 0 ? 0 : 0.8)}
              className="text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            >
              {masterVolume > 0 ? (
                <Volume2 className="h-4 w-4" />
              ) : (
                <VolumeX className="h-4 w-4 text-rose-500" />
              )}
            </button>
            <input
              id="master-volume-slider"
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={masterVolume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="flex-1 h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-blue-500 hover:accent-blue-400"
            />
          </div>
        </div>
      </div>

      {/* Scrub timeline slider bar */}
      <div className="relative pt-4 pb-2">
        <input
          id="playback-timeline-scrub"
          type="range"
          min="0"
          max={duration || 100}
          step="0.1"
          value={currentTime}
          onChange={handleScrub}
          className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer focus:outline-none accent-blue-500 hover:accent-blue-400
            [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-1.5 [&::-webkit-slider-thumb]:h-5 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:shadow-md [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:border [&::-webkit-slider-thumb]:border-blue-500"
        />
        {/* Endpoints Timestamps */}
        <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 mt-2">
          <span>00:00</span>
          {duration > 0 && (
            <span className="text-blue-400 font-semibold bg-blue-500/5 border border-blue-500/10 px-1.5 py-0.5 rounded">
              {formatTime(currentTime)}
            </span>
          )}
          <span>{formatTime(duration)}</span>
        </div>
      </div>
    </div>
  );
};
